<?php

if(isset($_POST['approve'])){

    require 'dbh.inc.php';

    $id = $_POST['id'];

    $select = "UPDATE tbl_users SET status = 'approved' WHERE id = '$id'";
    $result = mysqli_query($conn, $select);

    echo '<script type = "text/javascript">';
    echo 'alert("Company Approved!");';
    echo 'window.location.href = "admin-approval.php"';
    echo '</script>';
}

if(isset($_POST['deny'])){

    require 'dbh.inc.php';

    $id = $_POST['id'];

    $select = "DELETE FROM tbl_users WHERE id = '$id'";
    $result = mysqli_query($conn, $select);

    echo '<script type = "text/javascript">';
    echo 'alert("Company Denied!");';
    echo 'window.location.href = "admin-approval.php"';
    echo '</script>';
}
?>