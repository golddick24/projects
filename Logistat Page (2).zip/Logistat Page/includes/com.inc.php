<?php

if (isset($_POST['signup-submit'])) {

    require 'dbh.inc.php';

    $compName = $_POST['name'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $phoneNumber = $_POST['phonenumber'];
    $paymentModel = $_POST['paymentModel'];
    $password = $_POST['pwd'];
    $passwordRepeat = $_POST['pwd-repeat'];

    if (empty($compName) || empty($email) || empty($address) || empty($phoneNumber) || empty($paymentModel) || empty($password) || empty($passwordRepeat)) {

        header("location: ../company-reg.php?error=emptyfields&compname=".$compName."&email=".$email."&address=".$address."&phoneumber=".$phoneNumber."&paymentModel=".$paymentModel);
        exit();
    }
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) && !preg_match("/^[a-zA-Z0-9]*$/", $compName)) {
        header("location: ../company-reg.php?error=invalidmailname&compname=".$compName."&address=".$address."&phoneumber=".$phoneNumber."&paymentModel=".$paymentModel);
        exit();
    }

    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        header("location: ../company-reg.php?error=invalidmail&compname=".$compName."&address=".$address."&phoneumber=".$phoneNumber."&paymentModel=".$paymentModel);
        exit();
    }
    elseif (!preg_match("/^[a-zA-Z0-9]*$/", $compName)) {
        header("location: ../company-reg.php?error=invalidname&email=".$email."&address=".$address."&phoneumber=".$phoneNumber."&paymentModel=".$paymentModel);
        exit();
    }
    elseif ($password !== $passwordRepeat) {
        header("location: ../company-reg.php?error=passwordcheck&compName=".$compName."&email=".$email."&address=".$address."&phoneumber=".$phoneNumber."&paymentModel=".$paymentModel);
        exit();
    }
    else {

        $sql = "SELECT name FROM company_reg WHERE name=?";
        $stmt = mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($stmt, $sql)) {
            header("location: ../company-reg.php?error=sqlerror");
        exit();
        }
        else {
            mysqli_stmt_bind_param($stmt, "s", $compName);
            mysql_stmt_execute($stmt);
            mysqli_stmt_store_result($stmt);
            $resultCheck = mysqli_stmt_num_rows($stmt);
            if ($resultCheck > 0) {
                header("location: ../company-reg.php?error=nametaken&compname=".$compName."&email=".$email."&address=".$address."&phoneumber=".$phoneNumber."&paymentModel=".$paymentModel);
                exit();
            }
            else {
                $sql = "INSERT INTO company_reg (name, email, address, phone, paymentmodel, password) VALUES (?, ?, ?, ?, ?, ?)";
                $stmt = mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($stmt, $sql)) {
            header("location: ../company-reg.php?error=sqlerror");
        exit();
        }
        else {
            $hashpwd = password_hash($password, PASSWORD_DEFAULT)


            mysqli_stmt_bind_param($stmt, "sssiss", $compName, $email, $address, $phoneNumber, $paymentModel, $hashpwd);
            mysql_stmt_execute($stmt);
            header("Location: ../company-reg.php?signup=success");
            exit();
        }
            }
        }
    }

    mysqli_stmt_close($stmt);
    mysqli_close($conn);
}
else {
    header("Location: ../company-reg.php");
            exit();
}