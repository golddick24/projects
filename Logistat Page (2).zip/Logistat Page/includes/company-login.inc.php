<?php
    if(isset($_POST['login'])){

        require 'dbh.inc.php';

        $email = $_POST['email'];
        $password = $_POST['password'];

        $select = mysqli_query($conn, "SELECT * FROM company_reg WHERE email = '$email' AND password = '$password'");
        $row = mysqli_fetch_array($select);

        $status =$row['status'];

        $select2 = mysqli_query($conn, "SELECT * FROM company_reg WHERE email = '$email' AND password = '$password'");
        $check_user=mysqli_num_rows($select2);

        if($check_user==1){
            $_SESSION["status"]=$row['status'];
            $_SESSION["email"]=$row['email'];
            $_SESSION["password"]=$row['password'];

            if($status=="approved"){
                echo '<script type  = "text/javascript">';
                echo 'alert("Login Success!");';
                echo 'window.location.href = "Logistat-Admin/index.html.php"';
                echo '</script>';
            }
            elseif($status=="pending"){
                echo '<script type  = "text/javascript">';
                echo 'alert("Your account is still pending for approval!");';
                echo 'window.location.href = "company_login.php"';
                echo '</script>';
            }else{
                echo "Incorrect email or password!";
            }
        }

    }
?>